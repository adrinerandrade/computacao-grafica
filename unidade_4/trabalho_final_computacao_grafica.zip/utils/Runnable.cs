namespace gcgcg
{
  public delegate void Runnable();
}