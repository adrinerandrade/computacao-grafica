namespace gcgcg
{
  public delegate void Consumer<T>(T param);
}