* Para executar a música, é preciso entrar na pasta "player" e dar um "npm install".

* Para não executar a música, ir na classe MusicTimer, e comentar as linhas 23, 53 e 54.

* Caso não rodar no MAC, verificar o arquivo CG-N4.csproj e ver se não possui alguma dependência inválida.

Adriner Maranho de Andrade
Jorge Guilherme Kohn