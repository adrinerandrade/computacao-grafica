public abstract class ITextureTop: ITexture {

  public ITextureTop() {
    this.IsTop = true;
  }
    
}