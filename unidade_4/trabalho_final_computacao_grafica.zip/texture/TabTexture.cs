public class TabTexture: ITextureTop {

    public TabTexture(int texture) {
        this.Texture = texture;
    }

}