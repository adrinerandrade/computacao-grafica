public class NoteTexture: ITextureTop {

    public NoteTexture(int texture) {
        this.Texture = texture;
    }

}